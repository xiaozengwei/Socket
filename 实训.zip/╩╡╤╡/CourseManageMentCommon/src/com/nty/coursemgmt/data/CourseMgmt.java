package com.nty.coursemgmt.data;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import javax.swing.JOptionPane;


public class CourseMgmt {
	private ArrayList<Course> allCourse=new ArrayList<Course>();

    private static CourseMgmt courseMgmt=null;

    private static String ElectiveCourseName="";
      
    public static CourseMgmt getInstance(boolean serve){
        if(courseMgmt==null){
            if(serve){
                courseMgmt=new CourseMgmtDB();
            }else{
                courseMgmt=new CourseMgmtNet();
            }
        }
        return courseMgmt;
    }

    public CourseMgmt(){
    }

	public CourseMgmt(String filename){
		load(filename);
	}
	/*
	public static void printStr(String str){
		System.out.println(str);
	}
	*/
    public void addCourse(Course c){
        this.allCourse.add(c);
    }

/*
	public void printAllCourse(){
		ArrayList<Course> ret=new ArrayList<Course>();
		for(int i=0;i<allCourse.size();i++){
			ret.add(allCourse.get(i+1));
		}
		GeneralGrid grid =new GeneralGrid();
		grid.setHasIndexColumn(true);
		grid.setTableName("课程表");
		grid.setHeader(new String[]{"课程名","教材","学分","教师","时间","教室","类型"});
		for(Course c:ret){
			grid.addRow(new String[]{
			c.getCourseName(),
			c.getTextbook(),
			c.getCredit(),
			UserMgmt.getInstance().findUserById(c.getTeacherId()).getUserName(),
			c.getTime(),
			c.getClassroom(),
			c.getCourseType()==CourseType.MUST?"必修":"选修"
			});
		}
		grid.ShowTable();
	}
	*/
    /*
	public void printAllCourse(){
		for(Course c :allCourse){
			printStr("courseName="+c.getCourseName());
			printStr("textbook="+c.getTextbook());
			printStr("credit="+c.getCredit());
			printStr("teacherId="+c.getTeacherId());
			printStr("time="+c.getTime());
			printStr("classroom="+c.getClassroom());
			printStr("myClassName="+c.getCourseName());	
			String x=c.getCourseType()==CourseType.MUST?"必修":"选修";
			printStr("courseType="+x);
			printStr("    ");
		}
	}
    */
//课程名查找课程
    public Course getCourse(String courseName){
        Course course =null;
        for(Course c:allCourse){
            if(c.getCourseName().equals(courseName)){
                course=c;
                break;
            }
        }
        return course;
    }
//replace
    public void replaceCourse(Course oldC,Course newC){
        int i=0;
        for(Course c:this.allCourse){
            if(c.getCourseName().equals(oldC.getCourseName())){
                this.allCourse.set(i, newC);
                break;
            }
            i++;
        }
    }
//一个学生的所有课程
	public ArrayList<Course> findCourses(String myClassName,String userId){
		ArrayList<Course> current =new ArrayList<Course>();
		ArrayList<String> userCourses=UserCourseRelationMgmt.getInstance(false).getUserCourseRel(userId);
	//	for(int i=0;i<userCourses.size();i++){
	//		System.out.println(userCourses.get(i));		
	//	}	
			for(Course c:allCourse){
				if(c.getMyClassName().equals(myClassName)){
					current.add(c);		
				}	
				for(String courseName:userCourses){
					if(c.getCourseName().equals(courseName)){
						current.add(c);
						break;
					}
				}	
			}
			return current;		
	}
	//find某个学生id的选修课
		public ArrayList<Course> findCourses(String userId){
		ArrayList<Course> current =new ArrayList<Course>();
		ArrayList<String> userCourses=UserCourseRelationMgmt.getInstance(false).getUserCourseRel(userId);
	//	for(int i=0;i<userCourses.size();i++){
	//		System.out.println(userCourses.get(i));		
	//	}	
			for(Course c:allCourse){	
				for(String courseName:userCourses){
					if(c.getCourseName().equals(courseName)){
						current.add(c);
						break;
					}
				}	
			}
			return current;		
	}
	
	//get所有选修课
	public ArrayList<Course> getElectiveCourses(){
		ArrayList<Course> current =new ArrayList<Course>();
		for(Course c:allCourse){
			if(c.getCourseType()==CourseType.ELECTIVE){
				current.add(c);
			}
		}
		return current;
	}
	//得到学生可选的选修课
    public ArrayList<Course> getUserElectedCourses(String id){
        ArrayList<Course> current =new ArrayList<Course>();
        ArrayList<Course> ret=this.findCourses(id);
		for(Course c:allCourse){
			if(c.getCourseType()==CourseType.ELECTIVE){
                if(!ret.contains(c)){
                    current.add(c);
                }				
			}
		}
		return current;
    }
    //get老师的课程
	public ArrayList<Course> getTeacherCourses(Teacher th){
		ArrayList<Course> ret=new ArrayList<Course>();
		for(Course c:allCourse){
			if(c.getTeacherId().equals(th.getTeacherId())){
				ret.add(c);
			}
		}
		return ret;
	}
	
	public void load(String filename){
    	BufferedReader reader = null;
    	try{
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename),"utf-8"));
    	//	File file=new File("courseinfo.csv");
    	//	reader=new BufferedReader(new FileReader(file));
    		String line;
    		line=reader.readLine();
    		while((line=reader.readLine())!=null){
    				String []s=line.split(",");
    				if(s.length!=8)
    				{
    					System.out.println("s len="+s.length);
    					continue;
    				}
    				String courseName=s[0];
    				String book=s[1];
    				String credit=s[2];
    				String teacherId=s[3];
    				String time=s[4];
    				String classroom=s[5];
    				String myclass=s[6];
    				String courseType=s[7];
    				
    				Course courses=new Course();
    				courses.setCourse(courseName);
    				courses.setTextbook(book);
    				courses.setCredit(credit);
    				courses.setTeacherId(teacherId);
    				courses.setTime(time);
    				courses.setClassroom(classroom);
    				courses.setMyClassName(myclass);
    				if(courseType.equals("M")){
    					courses.setCourseType(CourseType.MUST);
    				}else if(courseType.equals("E")){
    					courses.setCourseType(CourseType.ELECTIVE);
    				}
    				allCourse.add(courses);
    				
    		}		
    	}catch(IOException ex){
    		System.out.println("loadAllCourse IOException!");
    		ex.printStackTrace(); //输出分析错误原因
    	}finally{ //清除reader
    		if(reader!=null){
    			try{
    			reader.close();
    		}catch(IOException ex){
    			System.out.println("loadAllCourse IOException 2!");
    		}
    		}
 
    	}
    	System.out.println("Course number:"+allCourse.size());
    //	courseMgmt.printAllCourse();
    }
	
	public void save(){
		BufferedWriter writer=null;
		try{
		//	File file=new File("courseinfo.csv");
		//	writer=new BufferedWriter(new FileWriter(file));
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("courseinfo.csv"),"utf-8"));
			writer.write("课程名,教材,学分,教师工号,时间,教室,班级,类型");
			writer.write("\r\n");
		/*	for(Course c:allCourse){
				String courseType="";
				if(c.getCourseType()==(CourseType.ELECTIVE)){
					courseType="E";
				}else if(c.getCourseType()==(CourseType.MUST)){
					courseType="M";
				}
				writer.write(c.getCourseName()+","+c.getTextbook()+","+c.getCredit()+","+c.getTeacherId()+","+c.getTime()
					+","+c.getClassroom()+","+c.getMyClassName()+","+courseType);
		*/
			for(Course c:allCourse){
				writer.write(c.toString());
				writer.write("\r\n");
			}
		}catch(IOException ex){
			System.out.println("CourseMgmt.save IOException!");
    		ex.printStackTrace();
		}finally{
			if(writer!=null){	
			try{
    			writer.close();
    		}catch(IOException ex){
    			System.out.println("CourseMgmt.save IOException 2!");
    		}	
			}
		}		
	}
	public void deleteRel(String courseName){
		for(Course c:this.allCourse){
			if(c.getCourseName().equals(courseName)){
				allCourse.remove(c);
				break;
			}
		}
	}
        public void addClassCourseRelation(String coursename,String classname){}
        
        public void delClassCourseRelation(String coursename){}
}