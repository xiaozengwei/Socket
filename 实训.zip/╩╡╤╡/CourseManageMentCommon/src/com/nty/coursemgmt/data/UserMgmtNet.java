/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nty.coursemgmt.data;

import com.nty.coursemgmt.net.LogonRequest;
import com.nty.coursemgmt.net.MyRequest;
import com.nty.coursemgmt.net.MyResponse;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Administrator
 */
public class UserMgmtNet extends UserMgmt {
/*
    @Override 
    public ArrayList<Student> getAllStudent() {
        final ArrayList<Student> ret=new ArrayList<Student>();
        try {
            final Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userMgmt.getAllStudent()", null);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();

            Thread th = new Thread(new Runnable() {
                @Override
                public void run(){
                    InputStream inStm = null;
                    try {
                        inStm = sock.getInputStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));                        
                        String msg = null;
                        while ((msg = reader.readLine()) != null) {
                            if (msg == null) {
                                continue;
                            }
                            if (!msg.equals("NA")) {
                                MyResponse response = MyResponse.fromJson(msg);
                                ret.add((Student) response.fromJsonToUser());
                            }
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
                    } finally {
                        try {
                            inStm.close();
                        } catch (IOException ex) {
                            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });                
        }catch(IOException ex){
        ex.printStackTrace();
    }
        return ret;
    }    
     */
    @Override
    public User findUser(String userid, String password) {
        User ret = null;
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream stm = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stm));
            LogonRequest logon = new LogonRequest(userid, password);
            MyRequest myRequest = new MyRequest("UserMgmtDB.findUser", logon.toJson());
            writer.write(myRequest.toJson() + "\n");
            writer.flush();

            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            String msg = reader.readLine();
            if (!msg.equals("NA")) {
                MyResponse response = MyResponse.fromJson(msg);
                ret = response.fromJsonToUser();
            }
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret;
    }

    @Override
    public User findUserById(String id) {
        User ret = null;
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userMgmtDB.findUserById", id);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();

            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            String msg = reader.readLine();
            if (!msg.equals("NA")) {
                MyResponse response = MyResponse.fromJson(msg);
                ret = response.fromJsonToUser();
            }
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }

        return ret;
    }

    @Override
    public ArrayList<Student> getAllStudent() {
        ArrayList<Student> ret = new ArrayList<Student>();
        try {
            final Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userMgmtDB.getAllStudent", null);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();

            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            int i=0;
            int count=Integer.parseInt(reader.readLine());
            MyResponse response;
            while (i<count) {  
                String msg=reader.readLine();
                if (!msg.equals("NA")) {
                    response= MyResponse.fromJson(msg);
                    ret.add((Student)response.fromJsonToUser());
                }
                i++;
            }

        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret;
    }

    @Override
    public ArrayList<User> getAllUsers() {
        ArrayList<User> ret = new ArrayList<User>();
        try {
            final Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userMgmtDB.getAllUsers", null);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();

            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            int i=0;
            int count=Integer.parseInt(reader.readLine());
            MyResponse response;
            while (i<count) {  
                String msg=reader.readLine();
                if (!msg.equals("NA")) {
                    response= MyResponse.fromJson(msg);
                    ret.add(response.fromJsonToUser());
                }
                i++;
            }
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret;
    }

    @Override
    public void addUser(User user) {
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream stm = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stm));
            MyRequest myRequest = new MyRequest("userMgmtDB.addUser", user.toJson());
            myRequest.setClassName(user.getClass().getName());
            writer.write(myRequest.toJson() + "\n");
            writer.flush();

        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void deleteUser(String id) {
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userMgmtDB.deleteUser",id);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();
            
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void replaceUser(User oldU, User newU) {
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream stm = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stm));
            MyRequest myRequest1 = new MyRequest("userMgmtDB.replaceUser", oldU.toJson());
            myRequest1.setClassName(oldU.getClass().getName());
            MyRequest myRequest2 = new MyRequest("userMgmtDB.replaceUser", newU.toJson());
            myRequest2.setClassName(newU.getClass().getName());
            
            writer.write(myRequest1.toJson() + "\n");
            writer.write(myRequest2.toJson() + "\n");
            writer.flush();

        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getStudentNumOfClass(String className) {
       int count=0; 
       try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userMgmtDB.getStudentNumOfClass",className);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();
            
            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            count=Integer.parseInt(reader.readLine());         
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
       return count;
    }
    
}
