package com.nty.coursemgmt.data;
import java.util.ArrayList;

public class UserCourseRelation {
	private String userId;
	private ArrayList<String> courseList=new ArrayList<String>();
	
	public void setUserId(String id){		
		this.userId=id;
	}
	public String getUserId(){
		return this.userId;
	}
	
	public ArrayList<String> getCourseList(){
		return this.courseList;
	}
}
