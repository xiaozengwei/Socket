/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nty.coursemgmt.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author TR
 */
public class ClassNameMgmt {

    private ArrayList<ClassName> allClassNames = new ArrayList<ClassName>();
    private static ClassNameMgmt classNameMgmt = new ClassNameMgmtDB();

    protected ClassNameMgmt() {
        load();
    }

    public static ClassNameMgmt getInstance() {
        return classNameMgmt;
    }

    public ArrayList<String> getClassName() {
        ArrayList<String> ret = new ArrayList<String>();
        for (ClassName c : this.allClassNames) {
            if (!ret.contains(c.getClassName())) {
                ret.add(c.getClassName());
            }
        }
        return ret;
    }

    public ArrayList<ClassName> getAllClassNames() {
        return allClassNames;
    }

    public void addClassName(String name){
    }

    private void load() {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream("classnameinfo.csv"), "utf-8"));
            String line;
            line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                String s = line;
                ClassName c = new ClassName();
                c.setClassName(s);
                this.allClassNames.add(c);
            }
        } catch (IOException ex) {
            System.out.println("loadAllClassName IOException !");
        } finally {
            try {
                reader.close();
            } catch (IOException ex) {
                System.out.println("loadAllClassName IOException 2!");
            }
        }
    }

    public void save() {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("classnameinfo.csv"), "utf-8"));
            writer.write("班级");
            writer.write("\r\n");
            for (ClassName c : this.allClassNames) {
                writer.write(c.getClassName());
                writer.write("\r\n");
            }
        } catch (IOException ex) {
            System.out.println("CourseMgmt.save IOException!");
            ex.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ex) {
                    System.out.println("CourseMgmt.save IOException 2!");
                }
            }
        }
    }

}
