/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nty.coursemgmt.data;

import com.nty.coursemgmt.db.ConnectionManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author TR
 */
public class UserCourseRelationMgmtDB extends UserCourseRelationMgmt{

    @Override
    public void deleteRel(String id) {
        String sql="delete from usercourserelation where userId=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    @Override
    public void replaceUserId(String oldId, String newId) {
        String sql = "update usercourserelation set userid=? where userid =?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, newId);
            stmt.setString(2, oldId);
            stmt.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public int getStudentNumOfCourse(String courseName) {
        int ret = 0;
        String sql = "select count(*) from usercourserelation left join courseinfo on usercourserelation.courseId=courseinfo.id where courseinfo.coursename=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, courseName);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ret = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public void deleteRelByName(String courseName) {     
        String sql1="select id from courseinfo where coursename=?";
        String sql2="delete from usercourserelation where courseId=?";
        Connection con = ConnectionManager.getConnection();
        String courseId=null;
        try {
            PreparedStatement stmt1 = con.prepareStatement(sql1);
            stmt1.setString(1, courseName);
            ResultSet rs=stmt1.executeQuery();
            while(rs.next()){
                courseId=rs.getString("id");
            }
            PreparedStatement stmt2= con.prepareStatement(sql2);
            stmt2.setString(1, courseId);
            stmt2.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}
