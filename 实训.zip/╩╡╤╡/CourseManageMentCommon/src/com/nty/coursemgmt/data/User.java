package com.nty.coursemgmt.data;

import com.google.gson.Gson;


public abstract class User {
	private String userId;
	private String userPossword;
	private String userName;
	private String userType;
	/*
	public void setUserType(String type){
		this.userType=type;
	}
	
	public String getType(){
		return this.userType;
	}
	*/
	public void setUserId(String id){
		this.userId=id;
	}
	
	public String getUserId(){
		return this.userId;
	}
	
	public void setUserPossword(String possword){
		this.userPossword=possword;
	}
	
	public String getUserPossword(){
		return this.userPossword;
	}
	
	public void setUserName(String name){
		this.userName=name;
	}
	
	public String getUserName(){
		return this.userName;
	}
    public abstract String toJson();

}
