/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt.data;

import com.nty.coursemgmt.db.ConnectionManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class ClassNameMgmtDB extends ClassNameMgmt{

    @Override
    public ArrayList<String> getClassName() {
        ArrayList<String> ret=new ArrayList<String>();
        String sql = "select distinct classname from myclass ";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                ret.add(rs.getString("classname"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    public void addClassName(String name){
        User ret = null;
        String sql = "insert into myclass values(?)";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,name);
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}
