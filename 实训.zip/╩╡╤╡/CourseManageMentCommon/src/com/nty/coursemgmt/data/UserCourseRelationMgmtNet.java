/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nty.coursemgmt.data;

import com.nty.coursemgmt.net.LogonRequest;
import com.nty.coursemgmt.net.MyRequest;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author TR
 */
public class UserCourseRelationMgmtNet extends UserCourseRelationMgmt{

    @Override
    public void deleteRel(String id) {
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userCourseRelationMgmtDB.deleteRel",id);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void replaceUserId(String oldId, String newId) {
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            LogonRequest request=new LogonRequest(oldId,newId);
            MyRequest myRequest = new MyRequest("userCourseRelationMgmtDB.replaceUserId",request.toJson());
            writer.write(myRequest.toJson() + "\n");
            writer.flush();
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getStudentNumOfCourse(String courseName) {
        int count=0;
        try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userCourseRelationMgmtDB.getStudentNumOfCourse",courseName);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();
            
            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            count=Integer.parseInt(reader.readLine());         
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }

    @Override
    public void deleteRelByName(String courseName) {
         try {
            Socket sock = new Socket("127.0.0.1", 9000);
            OutputStream out = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out));
            MyRequest myRequest = new MyRequest("userCourseRelationMgmtDB.deleteRelByName",courseName);
            writer.write(myRequest.toJson() + "\n");
            writer.flush();
        } catch (IOException ex) {
            Logger.getLogger(UserMgmtNet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }




}
