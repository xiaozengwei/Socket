package com.nty.coursemgmt.data;

import com.google.gson.Gson;


public class Teacher extends User {
	private String teacherId;
	private String teacherName;
	
	public void setTeacherId(String id){
		this.teacherId=id;
		super.setUserId(id);
	}
	public String getTeacherId(){
		return this.teacherId;
	}
	
	public void setTeacherName(String name){
		this.teacherName=name;
		super.setUserName(name);
	}
	public String getTeacherName(){
		return this.teacherName;
	}
	
	public String toString(){
		String ret=this.teacherId+","+this.teacherName+",th,"+this.getUserPossword()+","+"na";
		return ret;
	}
    public String toJson(){
        return new Gson().toJson(this);
    }
	public static Teacher fromJson(String str){
        return new Gson().fromJson(str, Teacher.class);
    }
}
