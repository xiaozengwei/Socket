package com.nty.coursemgmt.data;

import com.google.gson.Gson;


public class Student extends User{
	private String studentId;
	private String studentName;
	private String myClassName;
        private int myClassId;
	public void setStudentId(String id){
		this.studentId=id;
		super.setUserId(id);
		}
		
	public void setStudentName(String name){
		this.studentName=name;
		super.setUserName(name);
	}
	
	public String getStudentId(){
		return this.studentId;
	}
	
	public String getStudentName(){
		return this.studentName;
	}
	
	public void setMyClassName(String name){
		this.myClassName=name;
	}
	public String getMyClassName(){
		return this.myClassName;
	}

    public int getMyClassId() {
        return myClassId;
    }

    public void setMyClassId(int myClassId) {
        this.myClassId = myClassId;
    }
	
	public String toString(){
		String ret=this.studentId+","+this.studentName+","+"st,"+this.getUserPossword()+","+this.myClassName;
		return ret;
	}

    public String toJson(){
        return new Gson().toJson(this);
    }
    public static Student fromJson(String str){
        return new Gson().fromJson(str, Student.class);
    }
}
