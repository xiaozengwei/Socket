package com.nty.coursemgmt.data;

import com.google.gson.Gson;


public class Admin extends User{
	private String adminId;
	private String adminName;
	
	public void setAdminId(String id){
		this.adminId=id;
		super.setUserId(id);
	}
	public String getAdminId(){
		return this.adminId;
	}
	
	public void setAdminName(String name){
		this.adminName=name;
		super.setUserName(name);
	}
	public String getAdminName(){
		return this.adminName;
	}
	
	public String toString(){
		String ret=this.adminId+","+this.adminName+",ad,"+this.getUserPossword()+","+"na";
		return ret;
	}

    public String toJson(){
        return new Gson().toJson(this);
    }
    public static Admin fromJson(String str){
        return new Gson().fromJson(str, Admin.class);
    }
}
