/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt.data;

import com.nty.coursemgmt.db.ConnectionManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class CourseMgmtDB extends CourseMgmt{

    public ArrayList<Course> getCourseFromResultSet(ResultSet rs) throws SQLException{
        ArrayList<Course> retCourses = new ArrayList<Course>();
        while(rs.next()){
                Course ret= new Course();
                ret.setCourse(rs.getString("coursename"));
                ret.setTextbook(rs.getString("book"));
                ret.setCredit(rs.getString("credit"));
                ret.setTeacherId(rs.getString("teacherId"));
                ret.setTime(rs.getString("time"));
                ret.setClassroom(rs.getString("classroom"));
                if(rs.getString("type").equals("M")){
                    ret.setCourseType(CourseType.MUST);
                }else if(rs.getString("type").equals("E")){
                    ret.setCourseType(CourseType.ELECTIVE);
                }
                ret.setMyClassName(rs.getString("classname"));                
                retCourses.add(ret);
            }
        return retCourses;
    }
    @Override
    public void addCourse(Course c) {
        String sql="insert into courseinfo (coursename,book,credit,teacherId,time,classroom,type) values(?,?,?,?,?,?,?)";
        String sql1="select id from myclass where classname=?";
        String sql2="select id from courseinfo where coursename=?";
        String sql3="insert into courseclassrelation (courseId,myclassId) values(?,?)";
        System.out.println(c.getCourseName());
        System.out.println(c.getMyClassName());
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,c.getCourseName());
            stmt.setString(2,c.getTextbook());
            stmt.setString(3,c.getCredit());
            stmt.setString(4,c.getTeacherId());
            stmt.setString(5,c.getTime());
            stmt.setString(6,c.getClassroom());
            String courseType = "";
            if (c.getCourseType() == (CourseType.ELECTIVE)) {
                courseType = "E";
            } else if (c.getCourseType() == (CourseType.MUST)) {
                courseType = "M";
            }
            stmt.setString(7,courseType);
            stmt.execute();
 
            String myclassId=null;
            PreparedStatement stmt1 = con.prepareStatement(sql1);
            stmt1.setString(1, c.getMyClassName());
            ResultSet rs=stmt1.executeQuery();
            while(rs.next()){
                myclassId=rs.getString("id");               
            }
            System.out.println("classId"+myclassId);
            String courseId=null;
            PreparedStatement stmt2=con.prepareStatement(sql2);
            stmt2.setString(1,c.getCourseName());
            rs=stmt2.executeQuery();
            while(rs.next()){
                courseId=rs.getString("id");
            }
            System.out.println("courseId"+courseId);
            if (c.getCourseType()==CourseType.MUST) {
                PreparedStatement stmt3 = con.prepareStatement(sql3);
//                JOptionPane.showMessageDialog(null, myclassId);
//                JOptionPane.showMessageDialog(null, courseId);
                stmt3.setString(1, courseId);
                stmt3.setString(2, myclassId);
                stmt3.execute();
            }     
            System.out.println("after");
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Course getCourse(String courseName) {
        Course ret = null;
        String sql = "select courseinfo.id,coursename,book,credit,teacherId,time,classroom,type,myclass.classname from courseinfo " +
                "left join courseclassrelation on courseclassrelation.courseId=courseinfo.id " +
                "left join myclass on myclass.id=courseclassrelation.myclassId where coursename=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, courseName);
            ResultSet rs = stmt.executeQuery();
            ArrayList<Course> retCourses = getCourseFromResultSet(rs);
            if(!retCourses.isEmpty()){
                ret=retCourses.get(0);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public ArrayList<Course> getTeacherCourses(Teacher th) {
        ArrayList<Course> ret = new ArrayList<Course>();
        Connection con = ConnectionManager.getConnection();
        String sql = "select courseinfo.id,coursename,book,credit,teacherId,time,classroom,type,myclass.classname from courseinfo " +
                    "left join courseclassrelation on courseclassrelation.courseId=courseinfo.id " +
                    "left join myclass on myclass.id=courseclassrelation.myclassId where teacherId=?";
        try {                 
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,th.getTeacherId());
            ResultSet rs=stmt.executeQuery();
            ret = getCourseFromResultSet(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public void deleteRel(String courseName) {
        String sql="delete from courseinfo where coursename=?";
        Connection con=ConnectionManager.getConnection();
        try{
            PreparedStatement stmt=con.prepareStatement(sql);
            stmt.setString(1,courseName);
            stmt.execute();
        }catch(SQLException ex){

        }
    }

    @Override
    public void replaceCourse(Course oldC, Course newC) {
        String sql = "update courseinfo set coursename=? , book=? , credit=? , teacherId=? , time=?,classroom=? ,type=? where coursename=?";
//        String sql1 = "select id from myclass where classname=?";
//        String sql2 = "select id from courseinfo where coursename  =?";
//       String sql3 = "update courseclassrelation set myclassId=? where courseId=?";
//       String sql4="";
//        String classId = "";
//        String courseId = "";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, newC.getCourseName());
            stmt.setString(2, newC.getTextbook());
            stmt.setString(3, newC.getCredit());
            stmt.setString(4, newC.getTeacherId());
            stmt.setString(5, newC.getTime());
            String newtype = "";
            if (newC.getCourseType().equals(CourseType.MUST)) {
                newtype = "M";
            } else if (newC.getCourseType().equals(CourseType.ELECTIVE)) {
                newtype = "E";
            }
            stmt.setString(6, newC.getClassroom());
            stmt.setString(7, newtype);
            stmt.setString(8, oldC.getCourseName());
            stmt.execute();

/*
            if (newtype.equals("M")) {
                PreparedStatement stmt1 = con.prepareStatement(sql1);
                stmt1.setString(1, newC.getMyClassName());
                ResultSet rs1 = stmt1.executeQuery();
                while (rs1.next()) {
                    classId = rs1.getString("id");
                }
                PreparedStatement stmt2 = con.prepareStatement(sql2);
                stmt2.setString(1, newC.getCourseName());
                ResultSet rs2 = stmt2.executeQuery();
                while (rs2.next()) {
                    courseId = rs2.getString("id");
                }
                PreparedStatement stmt3 = con.prepareStatement(sql3);
                stmt3.setString(1, classId);
                stmt3.setString(2, courseId);
                stmt3.execute();
            }else if(newtype.equals("E")){
                
            }
  */       
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public ArrayList<Course> findCourses(String myClassName, String userId) {
        ArrayList<Course> ret=new ArrayList<Course>();        
        String sql = "select coursename,book,credit,teacherId,time,classroom,type,myclass.classname from courseinfo " +
                "join courseclassrelation on courseinfo.id=courseclassrelation.courseId" +
                "join myclass on myclass.id=courseclassrelation.myclassId where myclass.classname=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,myClassName);
            ResultSet rs=stmt.executeQuery();
            ret=getCourseFromResultSet(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
       
        return ret;
    }

    @Override
    public void addClassCourseRelation(String coursename,String classname){
        String sql1 = "select id from courseinfo where coursename  =?";
        String sql2 = "select id from myclass where classname=?";
        String sql3="insert into courseclassrelation(courseId,myclassId) values(?,?)";
        Connection con=ConnectionManager.getConnection();
        String courseId=null;
        String myclassId=null;
        try{
            PreparedStatement stmt1=con.prepareStatement(sql1);
            stmt1.setString(1,coursename);
            ResultSet rs=stmt1.executeQuery();
            while(rs.next()){
                courseId=rs.getString(1);
            }
            
            PreparedStatement stmt2=con.prepareStatement(sql2);
            stmt2.setString(1,classname);
            rs=stmt2.executeQuery();
            while(rs.next()){
                myclassId=rs.getString("id");
            }
            
            PreparedStatement stmt3=con.prepareStatement(sql3);
            stmt3.setString(1,courseId);
            stmt3.setString(2,myclassId);
            stmt3.execute();
        }catch(SQLException ex){

        }
    }

    @Override
    public void delClassCourseRelation(String coursename) {
        String sql1 = "select id from courseinfo where coursename  =?";
        String sql2="delete from courseclassrelation where courseId=?";
        Connection con=ConnectionManager.getConnection();
        String courseId=null;
        try{
            PreparedStatement stmt1=con.prepareStatement(sql1);
            stmt1.setString(1,coursename);
            ResultSet rs=stmt1.executeQuery();
            while(rs.next()){
                courseId=rs.getString("id");
            }
            PreparedStatement stmt2=con.prepareStatement(sql2);
            stmt2.setString(1,courseId);
            stmt2.execute();         
        }catch(SQLException ex){

        }
    }
    
}


