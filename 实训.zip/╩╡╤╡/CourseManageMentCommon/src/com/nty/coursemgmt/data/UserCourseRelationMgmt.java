package com.nty.coursemgmt.data;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class UserCourseRelationMgmt {

    private ArrayList<UserCourseRelation> userCourseRel = new ArrayList<UserCourseRelation>();
    private static UserCourseRelationMgmt userCourseRelationMgmt = null;

    public static UserCourseRelationMgmt getInstance(boolean serve) {
        if (userCourseRelationMgmt == null) {
            if (serve) {
                userCourseRelationMgmt = new UserCourseRelationMgmtDB();
            } else {
                userCourseRelationMgmt = new UserCourseRelationMgmtNet();
            }
        }
        return userCourseRelationMgmt;
    }

    public ArrayList<UserCourseRelation> getUserCourseRel() {
        return userCourseRel;
    }

    protected UserCourseRelationMgmt() {
    }
    
    protected UserCourseRelationMgmt(String filename) {
        load(filename);
    }
    public ArrayList<String> getUserCourseRel(String userId) {
        ArrayList<String> ret = new ArrayList<String>();
        for (UserCourseRelation c : userCourseRel) {
            if (c.getUserId().equals(userId)) {
                for (int i = 0; i < c.getCourseList().size(); i++) {
                    ret.add(c.getCourseList().get(i));
                }
            }
        }
        return ret;
    }

    public void addUserCourse(String userId, String courseName) {
        boolean addSucesses = false;
        for (UserCourseRelation c : userCourseRel) {
            if (c.getUserId().equals(userId)) {
                c.getCourseList().add(courseName);
                addSucesses = true;
                break;
            }
        }
        if (!addSucesses) {
            UserCourseRelation ret = new UserCourseRelation();
            ret.setUserId(userId);
            ret.getCourseList().add(courseName);
            userCourseRel.add(ret);
        }
    }

    public boolean checkUserCourse(String userId, String course) {
        boolean ret = false;
        for (UserCourseRelation rel : userCourseRel) {
            if (!(rel.getUserId().equals(userId))) {
                continue;
            }
            for (String c : rel.getCourseList()) {
                if (c.equals(course)) {
                    ret = true;
                    return ret;
                }
            }
        }
        return ret;
    }

    public void save() {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("user_course_relation.csv"), "utf-8"));
//			File file=new File("user_course_relation.csv");
//			writer=new BufferedWriter(new FileWriter(file));
            writer.write("UserId,Course");
            writer.write("\r\n");
            for (UserCourseRelation c : userCourseRel) {
                writer.write(c.getUserId() + ",");
                //	System.out.println(userCourseRel.size());
                for (int i = 0; i < c.getCourseList().size(); i++) {
                    if (i != 0) {
                        writer.write("%");
                    }
                    writer.write(c.getCourseList().get(i));
                }
                writer.write("\r\n");
            }
        } catch (IOException ex) {
            System.out.println("UserCourseRelationMgmt.save IOException!");
            ex.printStackTrace(); //输出分析错误原因
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ex) {
                    System.out.println("UserCourseRelationMgmt.save IOException 2!");
                }

            }
        }
    }

    public void load(String filename) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "utf-8"));
//    		File file=new File("user_course_relation.csv");
//    		reader=new BufferedReader(new FileReader(file));
            String line;
            line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                String[] s = line.split(",");
                if (s.length != 2) {
                    System.out.println("s len=" + s.length);
                    continue;
                }
                String userId = s[0];
                String courses = s[1];
                UserCourseRelation rel = new UserCourseRelation();
                rel.setUserId(userId);
                String[] courseArray = courses.split("%");
                for (String c : courseArray) {
                    rel.getCourseList().add(c);
                }
                userCourseRel.add(rel);
            }
        } catch (IOException ex) {
            System.out.println("UserCourseRelationMgmt IOException!");
            ex.printStackTrace(); //输出分析错误原因
        } finally { //清除reader
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    System.out.println("UserCourseRelationMgmt IOException 2!");
                }
            }

        }
        System.out.println("Course number:" + userCourseRel.size());
    }

    public int getStudentNumOfCourse(String courseName) {
        int count = 0;
        for (UserCourseRelation c : userCourseRel) {
            for (String str : c.getCourseList()) {
                if (str.equals(courseName)) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    public void deleteRelationById(String id, String name) {
        for (UserCourseRelation c : userCourseRel) {
            if (c.getUserId().equals(id)) {
                c.getCourseList().remove(name);
            }
        }
    }

    public void deleteRel(String id) {
        for (UserCourseRelation c : userCourseRel) {
            if (c.getUserId().equals(id)) {
                userCourseRel.remove(c);
                break;
            }
        }
    }

    public void deleteRelByName(String courseName) {
        for (UserCourseRelation c : userCourseRel) {
            c.getCourseList().remove(courseName);
        }
    }

    public void replaceUserId(String oldId, String newId) {
        int i = 0;
        for (UserCourseRelation c : userCourseRel) {
            if (c.getUserId().equals(oldId)) {
                UserCourseRelation ret = c;
                ret.setUserId(newId);
                userCourseRel.set(i, ret);
                break;
            }
            i++;
        }
    }

    public void replaceCourseName(String oldName, String newName) {

        for (UserCourseRelation c : userCourseRel) {
            int i = 0;
            for (String str : c.getCourseList()) {
                if (str.equals(oldName)) {
                    c.getCourseList().set(i, newName);
                    break;
                }
                i++;
            }
        }
    }
}
