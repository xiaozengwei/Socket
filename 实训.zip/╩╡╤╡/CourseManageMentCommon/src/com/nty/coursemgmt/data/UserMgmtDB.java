/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nty.coursemgmt.data;

import com.nty.coursemgmt.db.ConnectionManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Administrator
 */
public class UserMgmtDB extends UserMgmt {

    private ArrayList<User> getUserFromResultSet(ResultSet rs) throws SQLException {
        ArrayList<User> ret = new ArrayList<User>();
        while (rs.next()) {
            String id = rs.getString("userId");
            String name = rs.getString("name");
            String type = rs.getString("type");
            String pwd = rs.getString("password");
            String myclass = rs.getString("classname");
            int myclassId=rs.getInt("myclassId");
            if (type.equals("st")) {
                Student st = new Student();
                st.setStudentId(id);
                st.setStudentName(name);
                st.setUserPossword(pwd);
                st.setMyClassName(myclass);
                st.setMyClassId(myclassId);
                ret.add(st);
            }

            if (type.equals("th")) {
                Teacher th = new Teacher();
                th.setTeacherId(id);
                th.setTeacherName(name);
                th.setUserPossword(pwd);
                ret.add(th);
            }

            if (type.equals("ad")) {
                Admin ad = new Admin();
                ad.setAdminId(id);
                ad.setAdminName(name);
                ad.setUserPossword(pwd);
                ret.add(ad);
            }
        }
        return ret;
    }

    @Override
    public ArrayList<User> getAllUsers() {
        ArrayList<User> ret = new ArrayList<User>();
        String sql = "select userId,name,type,password,myclassId,myclass.classname from userinfo left join myclass on userinfo.myclassId=myclass.id";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            ret = getUserFromResultSet(rs);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public ArrayList<Student> getAllStudent() {
        ArrayList<Student> ret = new ArrayList<Student>();
        String sql = "select userId,name,type,password,myclassId,myclass.classname from userinfo left join myclass on userinfo.myclassId=myclass.id where type='st'";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            ArrayList<User> retUsers = getUserFromResultSet(rs);

            for (User u : retUsers) {
                ret.add((Student) u);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public User findUser(String userid, String password) {
        User ret = null;
        String sql = "select userId,name,type,password,myclassId,myclass.classname from userinfo left join myclass on userinfo.myclassId=myclass.id where userid=? and password=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, userid);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            ArrayList<User> retUsers = getUserFromResultSet(rs);
            if (!retUsers.isEmpty()) {
                ret = retUsers.get(0);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public void addUser(User user) {
        User ret = null;
        
        String sql = "insert into userinfo(userid,name,type,password,myclassId) values(?,?,?,?,?)";    
        String sql1="select id from myclass where classname=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            PreparedStatement stmt1=con.prepareStatement(sql1);
            stmt.setString(1, user.getUserId());
            stmt.setString(2, user.getUserName());
            stmt.setString(4, user.getUserPossword());
            int myclassId = -1;
            stmt1.setString(1,((Student)user).getMyClassName());
            ResultSet rs=stmt1.executeQuery();
            while(rs.next()){
                myclassId=rs.getInt("id");
            }            
            if (user instanceof Student) {
                stmt.setString(3, "st");               
                stmt.setInt(5,myclassId);
            } else if (user instanceof Teacher) {
                stmt.setString(3, "th");
                stmt.setString(5, null);
            } else if (user instanceof Admin) {
                stmt.setString(3, "ad");
                stmt.setString(5, null);
            }
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public User findUserById(String id) {
        User ret = null;
        String sql = "select userId,name,type,password,myclassId,classname from userinfo left join myclass on userinfo.myclassId=myclass.id where userid=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            ArrayList<User> retUsers = getUserFromResultSet(rs);
            if (!retUsers.isEmpty()) {
                ret = retUsers.get(0);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public Student findUserByName(String name) {
        User ret = null;
        String sql = "select userId,name,type,password,myclassId,classname from userinfo left join myclass on userinfo.myclassId=myclass.id where type='st' and name=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            ArrayList<User> retUsers = getUserFromResultSet(rs);
            if (!retUsers.isEmpty()) {
                ret = retUsers.get(0);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return (Student) ret;
    }

    @Override
    public ArrayList<Student> findUserByClassName(String className) {
        ArrayList<Student> ret = new ArrayList<Student>();
        String sql = "select userId,name,type,password,myclassId,classname from userinfo left join myclass on userinfo.myclassId=myclass.id where type='st' and myclass.classname=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, className);
            ResultSet rs = stmt.executeQuery();
            ArrayList<User> retUsers = getUserFromResultSet(rs);

            for (User u : retUsers) {
                ret.add((Student) u);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public int getStudentNumOfClass(String className) {
        int ret = 0;
        String sql = "select count(*) from userinfo left join myclass on userinfo.myclassId=myclass.id where type='st' and myclass.classname=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, className);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ret = rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return ret;
    }

    @Override
    public void deleteUser(String id) {
        String sql = "delete from userinfo where userid=?";
        Connection con = ConnectionManager.getConnection();
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void replaceUser(User oldU, User newU) {
        System.out.println(oldU.getClass().getName());
        System.out.println(newU.getClass().getName());
        String sql = "update userinfo set userid=? , name=? , type=? , password=? , myclassId=? where userid =?";
        String sql1="select id from myclass where classname=?";
        Connection con = ConnectionManager.getConnection();
        System.out.println("this is 1");
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            PreparedStatement stmt1=con.prepareStatement(sql1);
            System.out.println("this is 2");
            stmt.setString(1, newU.getUserId());
            stmt.setString(2, newU.getUserName());
            stmt.setString(4, newU.getUserPossword());
            stmt.setString(6, oldU.getUserId());
            stmt1.setString(1,((Student)newU).getMyClassName());
            System.out.println("this is 3 ");
            int myclass =-1;
            ResultSet rs=stmt1.executeQuery();
            System.out.println("this is 4");
            System.out.println("before rs");
            while(rs.next()){
                myclass=rs.getInt("id");
            }            
            System.out.println("classname:"+((Student)newU).getMyClassName());
            System.out.println("myclass:"+myclass);
            System.out.println("after rs");
            
            if (newU instanceof Student) {
                stmt.setString(3, "st");
                JOptionPane.showMessageDialog(null, myclass);
                stmt.setInt(5, myclass);
            } else if (newU instanceof Teacher) {
                stmt.setString(3, "th");
                stmt.setString(5, null);
            } else if (newU instanceof Admin) {
                stmt.setString(3, "ad");
                stmt.setString(5, null);
            }
            
            System.out.println("before excute");
            stmt.execute();
            System.out.println("after excute");

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
   
}
