/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt.data;

/**
 *
 * @author Administrator
 */
public enum CourseType{
	MUST,
	ELECTIVE
}

