 package com.nty.coursemgmt.data;

import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class UserMgmt {

    private ArrayList<User> allUsers = new ArrayList<User>();
    private static UserMgmt userMgmt = null;

    public static UserMgmt getInstance(boolean serve) {
        if (userMgmt == null) {
            if (serve) {
                userMgmt = new UserMgmtDB();
            } else {
                userMgmt = new UserMgmtNet();
            }
        }
        return userMgmt;
    }

    protected UserMgmt() {
    }

    protected UserMgmt(String filename) {
        load(filename);
    }

    public void addUser(User user) {
        allUsers.add(user);
    }

    public ArrayList<User> getAllUsers() {
        return this.allUsers;
    }

    public User findUser(String userid, String password) {
        User retUser = null;
        for (int i = 0; i < allUsers.size(); i++) {
            if (allUsers.get(i).getUserId().equals(userid) && allUsers.get(i).getUserPossword().equals(password)) {

                retUser = allUsers.get(i);
                break;
            }
        }
        return retUser;
    }

    public User findUserById(String id) {
        User ret = null;
        for (User c : allUsers) {
            if (c.getUserId().equals(id)) {
                ret = c;
                break;
            }
        }
        return ret;
    }

    public Student findUserByName(String name) {
        Student ret = null;
        for (User c : allUsers) {
            if (c instanceof Student) {
                if (((Student) c).getStudentName().equals(name)) {
                    ret = (Student) c;
                    break;
                }
            }
        }
        return ret;
    }

    public ArrayList<Student> findUserByClassName(String className) {
        ArrayList<Student> ret = new ArrayList<Student>();
        for (User u : allUsers) {
            if (u instanceof Student) {
                Student userTmp = (Student) u;
                if (userTmp.getMyClassName().equals(className)) {
                    ret.add(userTmp);
                }
            }

        }
        return ret;
    }

    public int getStudentNumOfClass(String className) {
        int count = 0;
        for (User u : allUsers) {
            if (u instanceof Student) {
                Student userTmp = (Student) u;
                if (userTmp.getMyClassName().equals(className)) {
                    count++;
                }
            }

        }
        return count;
    }

    public ArrayList<Student> getAllStudent() {
        ArrayList<Student> ret = new ArrayList<Student>();
        for (User u : this.allUsers) {
            if (u instanceof Student) {
                Student st = (Student) u;
                ret.add(st);
            }
        }
        return ret;
    }

    private void load(String filename) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "utf-8"));
//    		File file=new File("userinfo.csv");
//    		reader=new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] s = line.split(",");
                if (s.length != 5) {
                    System.out.println("s len=" + s.length);
                    continue;
                }
                String id = s[0];
                String name = s[1];
                String type = s[2];
                String possword = s[3];
                String myClassName = s[4];
                if (type.equals("st")) {
                    Student st = new Student();
                    st.setStudentId(id);
                    st.setStudentName(name);
                    st.setUserPossword(possword);
                    st.setMyClassName(myClassName);
                    //		st.setUserType(type);
                    addUser(st);
                }

                if (type.equals("th")) {
                    Teacher th = new Teacher();
                    th.setTeacherId(id);
                    th.setTeacherName(name);
                    th.setUserPossword(possword);
                    //		th.setUserType(type);
                    addUser(th);
                }

                if (type.equals("ad")) {
                    Admin ad = new Admin();
                    ad.setAdminId(id);
                    ad.setAdminName(name);
                    ad.setUserPossword(possword);
                    //		ad.setUserType(type);
                    addUser(ad);
                }
            }
        } catch (IOException ex) {
            System.out.println("loadAllUsers IOException!");
            ex.printStackTrace(); //输出分析错误原因
        } finally { //清除reader
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    System.out.println("loadAllUsers IOException 2!");
                }
            }
            //		System.out.println("User number:"+getCount());
            //		userMgmt.printAllUsers();
        }

    }

    public void save() {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("userinfo.csv"), "utf-8"));
//			File file=new File("userinfo.csv");
//			writer=new BufferedWriter(new FileWriter(file));
            writer.write("UserId,用户名,用户类型,密码,班级");
            writer.write("\r\n");
            for (User c : allUsers) {
                writer.write(c.toString());
                writer.write("\r\n");
            }
        } catch (IOException ex) {
            System.out.println("CourseMgmt.save IOException!");
            ex.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ex) {
                    System.out.println("CourseMgmt.save IOException 2!");
                }
            }
        }
    }

    public void deleteUser(String id) {
        for (User u : allUsers) {
            if (u.getUserId().equals(id)) {
                allUsers.remove(u);
                break;
            }
        }
    }

    public void replaceUser(User oldU, User newU) {
        int i = 0;
        for (User u : this.allUsers) {
            if (oldU.getUserId().equals(u.getUserId())) {
                allUsers.set(i, newU);
                break;
            }
            i++;
        }
    }
}
