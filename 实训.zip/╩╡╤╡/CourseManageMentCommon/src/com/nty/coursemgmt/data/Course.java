package com.nty.coursemgmt.data;

import com.google.gson.Gson;

public class Course {
	private String courseName;
	private String textbook;
	private String credit;
	private String teacherId;
	private String time;
	private String classroom;
	private String myClassName;
	private CourseType courseType;
	
	public void setCourseType(CourseType courseType){
		this.courseType=courseType;
	}
	public CourseType getCourseType(){
		return this.courseType;
	}
	
	public void setCourse(String course){
		this.courseName=course;
	}
	public String getCourseName(){
		return this.courseName;
	}
	
	public void setTextbook(String textbook){
		this.textbook=textbook;
	}
	public String getTextbook(){
		return this.textbook;
	}
	
	public void setCredit(String credit){
		this.credit=credit;
	}
	public String getCredit(){
		return credit;
	}
	
	public void setTeacherId(String teacherId){
		this.teacherId=teacherId;
	}
	public String getTeacherId(){
		return this.teacherId;
	}
	
	public void setTime(String time){
		this.time=time;
	}
	public String getTime(){
		return time;
	}

	public void setClassroom(String classroom){
		this.classroom=classroom;
	}
	public String getClassroom(){
		return classroom;
	}
	
	public void setMyClassName(String myClassName){
		this.myClassName=myClassName;
	}
	public String getMyClassName(){
		return myClassName;
	}
	
	public String toString(){
		String ret=courseName+","+textbook+","+credit+","+teacherId+","+time+","+classroom+","+myClassName+",";
		if(courseType==CourseType.MUST){
			ret+="M";
		}else if(courseType==CourseType.ELECTIVE){
			ret+="E";
		}
		return ret;
	}

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Course)){
            return false;
        }
        Course c=(Course)obj;
        if(!this.courseName.equals(c.getCourseName())
                ||!this.textbook.equals(c.getTextbook())
                ||!this.credit.equals(c.getCredit())
                ||!this.time.equals(c.getTime())
                ||!this.classroom.equals(c.getClassroom())
                ||!this.teacherId.equals(c.getTeacherId())
                ||this.courseType!=c.getCourseType()
                ||!this.myClassName.equals(c.getMyClassName()))return false;
        return true;
    }
    public String toJson(){
        return new Gson().toJson(this);
    }
	
    public static Course fromJson(String msg){
        return new Gson().fromJson(msg,Course.class);
    }
}
