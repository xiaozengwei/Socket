/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt.net;

import com.google.gson.Gson;
import com.nty.coursemgmt.data.Admin;
import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.Student;
import com.nty.coursemgmt.data.Teacher;
import com.nty.coursemgmt.data.User;

/**
 *
 * @author Administrator
 */
public class MyRequest {
    private String functionName;
    private String paramJson;
    private String className;
    public MyRequest(String functionName, String paramJson) {
        this.functionName = functionName;
        this.paramJson = paramJson;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getParamJson() {
        return paramJson;
    }

    public void setParamJson(String paramJson) {
        this.paramJson = paramJson;
    }

    public String toJson(){
        return new Gson().toJson(this);
    }
    public static MyRequest fromJson(String str){
        return new Gson().fromJson(str, MyRequest.class);
    }
    public LogonRequest fromJsonToLogonRequest(){
        return new Gson().fromJson(paramJson, LogonRequest.class);
    }
    public Course fromJsonToCourse(){
        return new Gson().fromJson(paramJson,Course.class);
    }
    public User fromJsonToUser(){
        User ret=null;
        if(className.equals("com.nty.coursemgmt.data.Student")){
            Student st=Student.fromJson(paramJson);
            ret=st;
        }else if(className.equals("com.nty.coursemgmt.data.Teacher")){
            Teacher th=Teacher.fromJson(paramJson);
            ret=th;
        }else if(className.equals("com.nty.coursemgmt.data.Admin")){
            Admin ad=Admin.fromJson(paramJson);
            ret=ad;
        }    
        return ret;
    }
}
