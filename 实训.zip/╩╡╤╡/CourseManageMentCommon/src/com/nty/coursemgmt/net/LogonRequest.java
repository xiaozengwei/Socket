/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt.net;

import com.google.gson.Gson;

/**
 *
 * @author Administrator
 */
public class LogonRequest {
    private String userId;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LogonRequest(String userId, String password) {
        this.userId = userId;
        this.password = password;
    }


    public String toJson(){
        return new Gson().toJson(this);
    }

    public static LogonRequest fromJson(String str){
        return new Gson().fromJson(str, LogonRequest.class);
    }
}
