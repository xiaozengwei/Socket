/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt.net;

import com.google.gson.Gson;
import com.nty.coursemgmt.data.Admin;
import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.Student;
import com.nty.coursemgmt.data.Teacher;
import com.nty.coursemgmt.data.User;

/**
 *
 * @author Administrator
 */
public class MyResponse {
    private String className;
    private String objJson;

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getObjJson() {
        return objJson;
    }

    public void setObjJson(String objJson) {
        this.objJson = objJson;
    }

    public MyResponse(String className, String objJson) {
        this.className = className;
        this.objJson = objJson;
    }
    public String toJson(){
        return new Gson().toJson(this);
    }

    public static MyResponse fromJson(String str){
        return new Gson().fromJson(str, MyResponse.class);
    }

    public User fromJsonToUser(){
        User ret=null;
        if(className.equals("com.nty.coursemgmt.data.Student")){
            Student st=Student.fromJson(objJson);
            ret=st;
        }else if(className.equals("com.nty.coursemgmt.data.Teacher")){
            Teacher th=Teacher.fromJson(objJson);
            ret=th;
        }else if(className.equals("com.nty.coursemgmt.data.Admin")){
            Admin ad=Admin.fromJson(objJson);
            ret=ad;
        }

        return ret;
    }
    public Course fromJsonToCourse() {
        return Course.fromJson(objJson);
    }
}
