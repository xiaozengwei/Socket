package com.nty.coursemgmt.common;
import java.util.ArrayList;

public class GeneralGrid {
	private String[] header;
	//get rows
	private ArrayList<String[]> rows=new ArrayList<String[]>();
	
	private String lineItem="-";
	private String divider="|";
	private String tableName=null;
	private boolean hasIndexColumn=false;
		
	//boolean是否设置序号
	public void setHasIndexColumn(boolean a){ 
		this.hasIndexColumn=a;
	}
	
	//左右分隔符
	private void printDivider(){
		System.out.print(divider);
	}
	//上下分隔符	
	public void setLineItem(String item){
		this.lineItem = item;
		}
		
	//设置左右分隔符
	public void setDivider(String divider){
		this.divider = divider;
		}	
		
	//设置表格表头
	public void setTableName(String name){
		this.tableName=name;
	}
	//得到具体的row
	public String[] getRow(int index){
		return this.rows.get(index-1);
	}
	public int getCount(){
		return this.rows.size();
	}
	
	//打印表格 header & rows
	public void ShowTable(){
		int[] columnMaxLen=new int[header.length];
		for(int i=0;i<header.length;i++){
			columnMaxLen[i]=getStrDisplayLen(header[i]);
		}
		
		for(String []row:rows){
			for(int i=0;i<header.length;i++){
				if(columnMaxLen[i]<getStrDisplayLen(row[i])){
					columnMaxLen[i]=getStrDisplayLen(row[i]);
				}
			}
		}
		int tableWidth=0;

		for(int i=0;i<header.length;i++){
			tableWidth+=columnMaxLen[i];
		}
		tableWidth+=divider.length()*header.length;

		if(tableName!=null){
			printDivider();
			printStrMiddle(tableName,tableWidth-2*divider.length());
			printDivider();
			System.out.println("");
		}
		
		printLine(tableWidth,lineItem);
		System.out.print(divider);
		for(int i=0;i<header.length;i++){
			printAutoAppemd(header[i],columnMaxLen[i]);
			System.out.print(divider);
		}	
	
		System.out.println("");
		printLine(tableWidth,lineItem);
		for(String[] row:rows){
			System.out.print(divider);
			for(int i=0;i<row.length;i++){
				printAutoAppemd(row[i],columnMaxLen[i]);
				System.out.print(divider);
			}	
			System.out.println("");
			printLine(tableWidth,lineItem);
		}
		
	}
	
	//设置表头
	public void setHeader(String[] h){
		if(this.hasIndexColumn){
			this.header=new String[h.length+1];
			header[0]="序号";
			for(int i=0;i<h.length;i++){
				this.header[i+1]=h[i];
			}	
		}else{
			this.header=h;
		}
	}
	
	//设置rows
	public void addRow(String[] row){
		if(this.hasIndexColumn){
			String[] newRow=new String[row.length+1];
			newRow[0]=String.valueOf(this.rows.size()+1);
			for(int i=0;i<row.length;i++){
				newRow[i+1]=row[i];
			}
			this.rows.add(newRow);
		}else{
			this.rows.add(row);
		}
		
	}
	
	//计算字符串长度(中文和字母)	
	private int getStrDisplayLen(String str){
		int len=0;
		for(int i=0;i<str.length();i++){
			char c=str.charAt(i);
			len=c>0x80?len+2:len+1;
		}	
		return len;
	}
	
	//自动补全
	private void printAutoAppemd(String item,int fixLen){
		int len=getStrDisplayLen(item);
		System.out.print(item);	
		for(int i=0;i<fixLen-len;i++){
			System.out.print(" ");
		}
	}
	
	//居中自动补全
	private void printStrMiddle(String item,int fixLen){
		int len=getStrDisplayLen(item);
		int strBefore=(fixLen-len)/2;
		int strAfter=fixLen-len-strBefore;
		for(int i=0;i<strBefore;i++){
			System.out.print(" ");
		}
		System.out.print(item);
		for(int i=0;i<strAfter;i++){
			System.out.print(" ");
		}
	}
	
	private void printLine(int len,String it){
		for(int i=0;i<len;i++){
			System.out.print(it);
		}
		System.out.println(it);
	}
}
