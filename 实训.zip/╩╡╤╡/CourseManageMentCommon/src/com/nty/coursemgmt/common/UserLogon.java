package com.nty.coursemgmt.common;
import com.nty.coursemgmt.data.User;
import com.nty.coursemgmt.data.UserMgmt;
import com.nty.coursemgmt.*;
import java.util.Scanner;

public class UserLogon {
	public static User currentUser=null;
	
	public static User getCurrentUser(){
		return currentUser;
	}
	
	
	public static void Logon() throws MyException{
		Scanner sc=new Scanner(System.in);
		System.out.print("userid:");
		String userid=sc.next();
		System.out.print("possword:");
		String possword=sc.next();
		
		currentUser=UserMgmt.getInstance(false).findUser(userid,possword);
		if(currentUser!=null){
			System.out.println("登陆成功");
		}else{
			throw new MyException("账号或密码错误");
		}
	}

    public static boolean Logon(String userId,String password){
        currentUser=UserMgmt.getInstance(false).findUser(userId,password);
        boolean ret=false;
        ret=currentUser==null?false:true;
        return ret;
    }

}
