package com.nty.coursemgmt.common;


public class MyException extends Exception {
	String errorMsg;
	MyException(String msg){
		this.errorMsg=msg;
	}
public String getErrorMsg(){
		return this.errorMsg;
	}
}
