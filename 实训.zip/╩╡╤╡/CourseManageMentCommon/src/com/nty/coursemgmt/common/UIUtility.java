package com.nty.coursemgmt.common;
import java.util.Scanner;

//工具类
public class UIUtility {
	public static int getStrDisplayLen(String str){
		int len=0;
		for(int i=0;i<str.length();i++){
			char c=str.charAt(i);
			len=c>0x80?len+2:len+1;
		}	
		return len;
	}
	
	public static void printAutoAppemd(String item,int fixLen){
		int len=getStrDisplayLen(item);
		System.out.print(item);	
	
		for(int i=0;i<fixLen-len-1;i++){
			System.out.print(" ");
		
		}
		System.out.print("|");
	}
	
	public static void printLine(int len,String it){
		for(int i=0;i<len;i++){
			System.out.print(it);
		}
		System.out.println(it);
	}
	
	//菜单1.## 2.## 3.##
	public static int printMenu(String[] menuItems){
		int select;
		Scanner sc=new Scanner(System.in);
		System.out.println("");
		for(String c:menuItems){
			printStr(c);
		}
			System.out.println("");
			System.out.print("请选择:");
			select=sc.nextInt();
			System.out.println("");
			return select;
	}
	
	public static void printStr(String str){
		System.out.print(str+"\t");
	}
	
	public static String inputItem(String item){
		Scanner sc=new Scanner(System.in);
		System.out.print(item+"\t");
		String str=sc.next();
		return str;
	}
}
