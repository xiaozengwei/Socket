/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nty.coursemgmt.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Administrator
 */
public class ConnectionManager {
    private static String connectionUrl = "jdbc:sqlserver://DESKTOP-2LHBK0N;databasename=course;user=sa;password=123456";
    public static Connection getConnection() {
        Connection ret = null;
        try {
            ret = DriverManager.getConnection(connectionUrl);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return ret;
    }
}
