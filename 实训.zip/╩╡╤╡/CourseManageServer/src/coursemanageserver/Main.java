
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package coursemanageserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class Main {
    private static ServerSocket serSock =null;
    private static ArrayList<SocketHandler> HandlerList=new ArrayList<SocketHandler>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            if (serSock == null) {
                serSock = new ServerSocket(9000);
                System.out.println("启动服务成功");
            }
            while (true) {
                System.out.println("before accept");
                Socket sock = serSock.accept();
                System.out.println("after accept");
                SocketHandler handler=new SocketHandler(sock);
                HandlerList.add(handler);
                Thread th = new Thread(handler);

      /*          Thread th = new Thread(new Runnable() {
                    public void run() {
                        receiveClientMsg(sock);
                    }
                });
       * */
                th.start();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        // TODO code application logic here
    }

}
