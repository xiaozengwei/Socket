/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coursemanageserver;

import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.CourseMgmt;
import com.nty.coursemgmt.data.Student;
import com.nty.coursemgmt.data.Teacher;
import com.nty.coursemgmt.data.User;
import com.nty.coursemgmt.data.UserCourseRelationMgmt;
import com.nty.coursemgmt.data.UserMgmt;
import com.nty.coursemgmt.net.LogonRequest;
import com.nty.coursemgmt.net.MyRequest;
import com.nty.coursemgmt.net.MyResponse;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class SocketHandler implements Runnable {

    private Socket sock;

    SocketHandler(Socket sock) {
        this.sock = sock;
    }

    public void run() {
        receiveClientMsg(sock);
    }

    private String processLogonRequest(MyRequest myRequest) {
        String str = null;
        LogonRequest request = myRequest.fromJsonToLogonRequest();
        String userId = request.getUserId();
        String password = request.getPassword();
        User ret = UserMgmt.getInstance(true).findUser(userId, password);
        if (ret != null) {
            MyResponse respsonse = new MyResponse(ret.getClass().getName(), ret.toJson());
            str = respsonse.toJson();
        }
        return str;
    }


    private void receiveClientMsg(Socket sock) {
        try {
            InputStream inStm = sock.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStm));
            while (true) {
                String msg = reader.readLine();
                if (msg == null) {
                    continue;
                }
                MyRequest myRequest = MyRequest.fromJson(msg);
                //findUser
                if (myRequest.getFunctionName().equals("UserMgmtDB.findUser")) {
                    String resp = this.processLogonRequest(myRequest);
                    IsSendToClient(resp);
                }
                //findUserById             
                if(myRequest.getFunctionName().equals("userMgmtDB.findUserById")){
                    
                    String str=null;
                    User ret=UserMgmt.getInstance(true).findUserById(myRequest.getParamJson());
                    if(ret!=null){
                        MyResponse myResponse=new MyResponse(ret.getClass().getName(),ret.toJson());
                        str=myResponse.toJson();    
                    }
                        IsSendToClient(str);
                }
                //"userMgmt.getAllStudent"
                if(myRequest.getFunctionName().equals("userMgmtDB.getAllStudent")){
                    ArrayList<Student> ret=UserMgmt.getInstance(true).getAllStudent();
                    int count=ret.size();
                    sendToClient(String.valueOf(count));
                    if(!ret.isEmpty()){
                        for(Student st:ret){
                            MyResponse myResponse=new MyResponse(st.getClass().getName(),st.toJson());
                            sendToClient(myResponse.toJson());
                        }
                    }else{
                        sendToClient("NA");
                    }
                }
                //"userMgmt.getAllUsers"
                if(myRequest.getFunctionName().equals("userMgmtDB.getAllUsers")){
                    ArrayList<User> ret=UserMgmt.getInstance(true).getAllUsers();
                    int count=ret.size();
                    sendToClient(String.valueOf(count));
                    if(!ret.isEmpty()){
                        for(User u:ret){
                            MyResponse myResponse=new MyResponse(u.getClass().getName(),u.toJson());
                            sendToClient(myResponse.toJson());
                        }
                    }else{
                        sendToClient("NA");
                    }
                }
                //"userMgmtDB.addUser"
                if(myRequest.getFunctionName().equals("userMgmtDB.addUser")){
                  UserMgmt.getInstance(true).addUser(myRequest.fromJsonToUser());
                }
                //"userMgmtDB.deleteUser"
                if(myRequest.getFunctionName().equals("userMgmtDB.deleteUser")){
                    System.out.println("this is userMgmtDB.deleteUser ");
                    UserMgmt.getInstance(true).deleteUser(myRequest.getParamJson());
                }
                //"userMgmtDB.replaceUser"
                if(myRequest.getFunctionName().equals("userMgmtDB.replaceUser")){
                    User oldU=myRequest.fromJsonToUser();
                    System.out.println(oldU.getClass().getName());
                    msg=reader.readLine();
                    myRequest=MyRequest.fromJson(msg);
                    User newU=myRequest.fromJsonToUser();      
                    System.out.println(newU.getClass().getName());
                    UserMgmt.getInstance(true).replaceUser(oldU, newU);
                }              
                //"userMgmtDB.getStudentNumOfClass"
                if(myRequest.getFunctionName().equals("userMgmtDB.getStudentNumOfClass")){
                    int count=UserMgmt.getInstance(true).getStudentNumOfClass(myRequest.getParamJson());
                    sendToClient(String.valueOf(count));                   
                }
                
                //-------------------------------------------------------------------------------
                //"courseMgmtDB.getTeacherCourses"
                if(myRequest.getFunctionName().equals("courseMgmtDB.getTeacherCourses")){
                    Teacher th=(Teacher)myRequest.fromJsonToUser();
                    ArrayList<Course> ret=CourseMgmt.getInstance(true).getTeacherCourses(th);
                    int count=ret.size();
                    sendToClient(String.valueOf(count));
                    if(!ret.isEmpty()){
                        for(Course c:ret){
                            MyResponse myResponse=new MyResponse(c.getClass().getName(),c.toJson());
                            sendToClient(myResponse.toJson());
                        }
                    }else{
                        sendToClient("NA");
                    }
                }
                //"courseMgmtDB.addCourse"
                if(myRequest.getFunctionName().equals("courseMgmtDB.addCourse")){
                    CourseMgmt.getInstance(true).addCourse(myRequest.fromJsonToCourse());
                }
                //"courseMgmtDB.addClassCourseRelation"
                if(myRequest.getFunctionName().equals("courseMgmtDB.addClassCourseRelation")){
                    LogonRequest request=myRequest.fromJsonToLogonRequest();                   
                    CourseMgmt.getInstance(true).addClassCourseRelation(request.getUserId(),request.getPassword());
                }
                //"courseMgmtDB.getCourse"    
                if(myRequest.getFunctionName().equals("courseMgmtDB.getCourse")){
                    Course c=CourseMgmt.getInstance(true).getCourse(myRequest.getParamJson());
                    MyResponse myResponse=new MyResponse(c.getClass().getName(),c.toJson());
                    if(c!=null){
                        sendToClient(myResponse.toJson());
                    }else{
                        sendToClient("NA");
                    }
                }
                //"courseMgmtDB.deleteRel"
                if(myRequest.getFunctionName().equals("courseMgmtDB.deleteRel")){
                    CourseMgmt.getInstance(true).deleteRel(myRequest.getParamJson());
                }
                //"courseMgmtDB.delClassCourseRelation"
                if(myRequest.getFunctionName().equals("courseMgmtDB.delClassCourseRelation")){
                    CourseMgmt.getInstance(true).delClassCourseRelation(myRequest.getParamJson());
                }
                
                //-------------------------------------------------------------------------------
                //"userCourseRelationMgmtDB.deleteRel"
                if(myRequest.getFunctionName().equals("userCourseRelationMgmtDB.deleteRel")){
                    UserCourseRelationMgmt.getInstance(true).deleteRel(myRequest.getParamJson());
                }
                //userCourseRelationMgmtDB.replaceUserId
                if(myRequest.getFunctionName().equals("userCourseRelationMgmtDB.replaceUserId")){
                    LogonRequest request=myRequest.fromJsonToLogonRequest();
                    UserCourseRelationMgmt.getInstance(true).replaceUserId(request.getUserId(),request.getPassword());//userid->oldId , password->newId
                }    
                //"userCourseRelationMgmtDB.getStudentNumOfCourse"
                if(myRequest.getFunctionName().equals("userCourseRelationMgmtDB.getStudentNumOfCourse")){
                    int count=UserCourseRelationMgmt.getInstance(true).getStudentNumOfCourse(myRequest.getParamJson());
                    sendToClient(String.valueOf(count));
                }
                //"userCourseRelationMgmtDB.deleteRelByName"
                if(myRequest.getFunctionName().equals("userCourseRelationMgmtDB.deleteRelByName")){
                    UserCourseRelationMgmt.getInstance(true).deleteRelByName(myRequest.getParamJson());
                }
            }
           
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
        
    public void IsSendToClient(String str) {
        //判断str是否为空 
        if (str != null) {
            sendToClient(str);
        } else {
            sendToClient("NA");
        }
    }

    public void sendToClient(String msg) {
        try {
            OutputStream stm = sock.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stm));
            writer.write(msg + "\n");
            writer.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
