package com.nty.coursemgmt;

import com.nty.coursemgmt.data.mainUI;
import com.nty.coursemgmt.common.UserLogon;
import com.nty.coursemgmt.common.MyException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

public class CourseManageMent {
    
//    private static UserMgmt userMgmt=new UserMgmt();
//    private static CourseMgmt courseMgmt=new CourseMgmt();
//	private static UserCourseRelationMgmt userCourseRelationMgmt=new UserCourseRelationMgmt();
/*
    public static User findUser(String userid,String possword){
    	return userMgmt.findUser(userid,possword);
    }
    
    public static UserCourseRelationMgmt getUserCourseRelationMgmt(){
    	return userCourseRelationMgmt;
    	
    }
   
    public static CourseMgmt getCourseMgmt(){
    	return courseMgmt;
    }
   
    public static UserMgmt getUserMgmt(){
    	return userMgmt;
    }
    
	private static void loadAllUsers(){
    	BufferedReader reader = null;
    	try{
    		File file=new File("userinfo.csv");
    		reader=new BufferedReader(new FileReader(file));
    		String line;
    		while((line=reader.readLine())!=null){
    				String []s=line.split(",");
    				if(s.length!=5)
    				{
    					System.out.println("s len="+s.length);
    					continue;
    				}
    				String id=s[0];
    				String name=s[1];
    				String type=s[2];
    				String possword=s[3];
    				String myClassName=s[4];
    				if(type.equals("st")){
    					Student st=new Student();
    					st.setUserId(id);
    					st.setUserName(name);
    					st.setUserPossword(possword);
    					st.setMyClassName(myClassName);
    					st.setUserType(type);
    					userMgmt.addUser(st);	
    				}
    				
    				if(type.equals("th")){
    					Teacher th=new Teacher();
    					th.setUserId(id);
    					th.setUserName(name);
    					th.setUserPossword(possword);
    					th.setUserType(type);
    					userMgmt.addUser(th);
    				}
    				
    				if(type.equals("ad")){
    					Admin ad=new Admin();
    					ad.setUserId(id);
    					ad.setUserName(name);
    					ad.setUserPossword(possword);
    					ad.setUserType(type);
    					userMgmt.addUser(ad);
    				}
    		}		
    	}catch(IOException ex){
    		System.out.println("loadAllUsers IOException!");
    		ex.printStackTrace(); //输出分析错误原因
    	}finally{ //清除reader
    		if(reader!=null){
    			try{
    			reader.close();
    		}catch(IOException ex){
    			System.out.println("loadAllUsers IOException 2!");
    		}
    		}
    			System.out.println("User number:"+userMgmt.getCount());
    	//		userMgmt.printAllUsers();
    	}
   	
    }
    */
   
    public static void main(String[] args) {
        

    	System.out.println("****************"); 
        System.out.println("**课程管理系统**");
        System.out.println("****************");
       	try{
       		
//      	loadAllUsers();
//       	loadAllCourse();
       		UserLogon.Logon();
       		mainUI.showUI(UserLogon.getCurrentUser());
 

    }catch(ArrayIndexOutOfBoundsException ex){
    	System.out.println("ArrayIndexOutOfBoundsException!");
    }catch(MyException ex){
    	System.out.println("MyException:"+ex.getErrorMsg());
    }
    }
}
