package com.nty.coursemgmt.consoleui;
import com.nty.coursemgmt.data.CourseType;
import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.Student;
import com.nty.coursemgmt.data.CourseMgmt;
import com.nty.coursemgmt.data.UserMgmt;
import com.nty.coursemgmt.*;
import com.nty.coursemgmt.common.GeneralGrid;
import java.util.ArrayList;

public class CourseQueryUI {

	
	public static void printStr(String str){
		System.out.print(str);
	}
	public static void showUI(Student st){
		// get name
			String myClassName = st.getMyClassName() ;
		// find ArrayList
			ArrayList<Course> retCourse=CourseMgmt.getInstance(false).findCourses(myClassName,st.getStudentId());
		// total credit
		//	System.out.println(retCourse.size());
			int totalCredit=0 ;
			for(Course c:retCourse){
				totalCredit+=Integer.parseInt(c.getCredit());
			}
			GeneralGrid grid =new GeneralGrid();
			grid.setHasIndexColumn(true);
			grid.setTableName("课程表");
			grid.setHeader(new String[]{"课程名","教材","学分","教师","时间","教室","类型"});
			for(Course c:retCourse){
				grid.addRow(new String[]{
				c.getCourseName(),
				c.getTextbook(),
				c.getCredit(),
				UserMgmt.getInstance(false).findUserById(c.getTeacherId()).getUserName(),
				c.getTime(),
				c.getClassroom(),
				c.getCourseType()==CourseType.MUST?"必修":"选修"
				});
			}
			grid.ShowTable();
			
			GeneralGrid summayGrid=new GeneralGrid();
			summayGrid.setTableName("汇总");
			summayGrid.setHeader(new String[]{"总课程","总学分"});
			summayGrid.addRow(new String[]{String.valueOf(retCourse.size()),String.valueOf(totalCredit)});	
			summayGrid.ShowTable();		
	}
	/*
	public static void showUI2(Student st){
		//int[]column =new int[6];列
			int[] columnMaxLen=new int[6];
		// get name
			String myClassName = st.getMyClassName() ;
		// find ArrayList
			ArrayList<Course> retCourse=CourseMgmt.getInstance().findCourses(myClassName);
		//print
			columnMaxLen[0]=getStrDisplayLen("课程名");
			columnMaxLen[1]=getStrDisplayLen("教材");
			columnMaxLen[2]=getStrDisplayLen("学分");
			columnMaxLen[3]=getStrDisplayLen("教师");			
			columnMaxLen[4]=getStrDisplayLen("时间");	
			columnMaxLen[5]=getStrDisplayLen("教室");
			for(Course c:retCourse){
				columnMaxLen[0]=columnMaxLen[0]<getStrDisplayLen(c.getCourseName())?getStrDisplayLen(c.getCourseName()):columnMaxLen[0];
				columnMaxLen[1]=columnMaxLen[1]<getStrDisplayLen(c.getTextbook())?getStrDisplayLen(c.getTextbook()):columnMaxLen[1];
				columnMaxLen[2]=columnMaxLen[2]<getStrDisplayLen(c.getCredit())?getStrDisplayLen(c.getCredit()):columnMaxLen[2];
				String name=UserMgmt.getInstance().findUserById(c.getTeacherId()).getUserName();
				columnMaxLen[3]=columnMaxLen[3]<getStrDisplayLen(name)?getStrDisplayLen(name):columnMaxLen[3];
				columnMaxLen[4]=columnMaxLen[4]<getStrDisplayLen(c.getTime())?getStrDisplayLen(c.getTime()):columnMaxLen[4];
				columnMaxLen[5]=columnMaxLen[5]<getStrDisplayLen(c.getMyClassName())?getStrDisplayLen(c.getMyClassName()):columnMaxLen[5];
			}
			int total=0;
			for(int i=0;i<columnMaxLen.length;i++){
				columnMaxLen[i]+=2;
				total+=columnMaxLen[i];
			}
							
			printLine(total,"~");
			printAutoAppemd("课程名",columnMaxLen[0]);
			printAutoAppemd("教材",columnMaxLen[1]);
			printAutoAppemd("学分",columnMaxLen[2]);
			printAutoAppemd("教师",columnMaxLen[3]);
			printAutoAppemd("时间",columnMaxLen[4]);
			printAutoAppemd("教室",columnMaxLen[5]);
			System.out.println("");
			printLine(total,"~");
			for(Course c:retCourse){
				printAutoAppemd(c.getCourseName(),columnMaxLen[0]);
				printAutoAppemd(c.getTextbook(),columnMaxLen[1]);                                     
				printAutoAppemd(String.valueOf(c.getCredit()),columnMaxLen[2]);
				printAutoAppemd(UserMgmt.getInstance().findUserById(c.getTeacherId()).getUserName(),columnMaxLen[3]);
				printAutoAppemd(c.getTime(),columnMaxLen[4]);
				printAutoAppemd(c.getClassroom(),columnMaxLen[5]);	
				System.out.println("");	
				printLine(total,"-");
			}
		
	}
	*/
}
