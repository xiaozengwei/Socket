package com.nty.coursemgmt.consoleui;
import com.nty.coursemgmt.data.CourseType;
import com.nty.coursemgmt.data.UserCourseRelationMgmt;
import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.Teacher;
import com.nty.coursemgmt.data.CourseMgmt;
import com.nty.coursemgmt.data.UserMgmt;
import com.nty.coursemgmt.*;
import com.nty.coursemgmt.common.GeneralGrid;
import java.util.ArrayList;

public class TeacherCourseQueryUI {
	public void showUI(Teacher th){
		ArrayList<Course> retCourse=CourseMgmt.getInstance(false).getTeacherCourses(th);
		GeneralGrid grid =new GeneralGrid();
		grid.setHasIndexColumn(true);
		grid.setTableName(th.getTeacherName()+"的课程表");
		grid.setHeader(new String[]{"课程名","教材","学分","教师","时间","教室","类型","班级","人数"});
		
		for(Course c:retCourse){
			int count =0 ;
			if(c.getCourseType()==CourseType.MUST){
				count=UserMgmt.getInstance(false).getStudentNumOfClass(c.getMyClassName());
			}if(c.getCourseType()==CourseType.ELECTIVE){
				count=UserCourseRelationMgmt.getInstance(false).getStudentNumOfCourse(c.getCourseName());
			}
			grid.addRow(new String[]{
			c.getCourseName(),
			c.getTextbook(),
			c.getCredit(),
			UserMgmt.getInstance(false).findUserById(c.getTeacherId()).getUserName(),
			c.getTime(),
			c.getClassroom(),
			c.getCourseType()==CourseType.MUST?"普通":"选修",
			c.getMyClassName().equals("na")?"":c.getMyClassName(),
			String.valueOf(count)
			});
		}
		grid.ShowTable();
	}
	
/*	写入文件
	public static void save(){
		BufferedWriter writer=null;
		try{
			File =new File("courseinfo");
			writer=new BufferedWriter(new FileWriter(file));
			for(int i=0;i<CourseMgmt.getInstance().getAllCourse().size();i++){
				write()
			}			
		}catch(IOException ex){
			System.out.println("Save IOException 1!");
		}finally{
			if(writer!=null){
				try{
					writer.close();
				}catch(IOException ex){
					System.out.println("Save IOException 2!");
				}	
			}
		}
	}
*/
}
