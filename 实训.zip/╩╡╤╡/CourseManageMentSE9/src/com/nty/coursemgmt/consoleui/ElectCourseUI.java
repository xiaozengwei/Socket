package com.nty.coursemgmt.consoleui;
import com.nty.coursemgmt.data.UserCourseRelationMgmt;
import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.Student;
import com.nty.coursemgmt.data.CourseMgmt;
import com.nty.coursemgmt.data.UserMgmt;
import com.nty.coursemgmt.*;
import com.nty.coursemgmt.common.GeneralGrid;
import com.nty.coursemgmt.common.UIUtility;
import java.util.ArrayList;
import java.util.Scanner;

public class ElectCourseUI {
	private GeneralGrid grid=null;
	
	public void showUI(Student st){
		printElectiveCourses();
		int select=0;
		do{
			select=UIUtility.printMenu(new String[]{"1.开始选课","2.查看已选课程","0.退出"});
			switch(select){
				case 1:
					electCourse(st);
					break;
				case 2:
					printElectedCourses(st);
					break;
				default:
					break;
			}
				
		}while(select!=0);
		
	}
	
	private void electCourse(Student st){
		//用户输入序号
		System.out.print("input number:");
		Scanner sc=new Scanner(System.in);
		int select=sc.nextInt();
		if(!(select>0&&select<=grid.getCount())){
			System.out.println("输入的序号不合法!!");
			return;
		}
		//更新用户课程
		String[] row=grid.getRow(select);
		String courseName=row[1];
		if(UserCourseRelationMgmt.getInstance(false).checkUserCourse(st.getStudentId(),courseName)){
			System.out.println("此课已选过");
			return;
		}
		UserCourseRelationMgmt.getInstance(false).addUserCourse(st.getStudentId(),courseName);
		
		//更新文件
		UserCourseRelationMgmt.getInstance(false).save();
		
		System.out.println("选课成功");
	}
	
	
	private void printElectedCourses(Student st){
		ArrayList<Course> retCourses=CourseMgmt.getInstance(false).findCourses(st.getStudentId());
		GeneralGrid gridTmp =new GeneralGrid();
		gridTmp.setTableName(st.getStudentName()+"的已选课程信息");
		gridTmp.setHasIndexColumn(true);
		gridTmp.setHeader(new String[]{"课程名","教材","学分","教师","时间","教室"
		});
		for(Course c:retCourses){
				gridTmp.addRow(new String[]{
				c.getCourseName(),
				c.getTextbook(),
				c.getCredit(),
				UserMgmt.getInstance(false).findUserById(c.getTeacherId()).getUserName(),
				c.getTime(),
				c.getClassroom()
				});
			}
			gridTmp.ShowTable();
	
	}
	
	
	private void printElectiveCourses(){
		ArrayList<Course> retCourses=CourseMgmt.getInstance(false).getElectiveCourses();
		grid =new GeneralGrid();
		grid.setTableName("可选课程信息");
		grid.setHasIndexColumn(true);
		grid.setHeader(new String[]{"课程名","教材","学分","教师","时间","教室"
		});
		for(Course c:retCourses){
				grid.addRow(new String[]{
				c.getCourseName(),
				c.getTextbook(),
				c.getCredit(),
				UserMgmt.getInstance(false).findUserById(c.getTeacherId()).getUserName(),
				c.getTime(),
				c.getClassroom()
				});
			}
			grid.ShowTable();
	}
}
