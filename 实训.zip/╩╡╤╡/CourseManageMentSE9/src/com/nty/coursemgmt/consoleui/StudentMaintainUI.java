package com.nty.coursemgmt.consoleui;
import com.nty.coursemgmt.data.UserCourseRelationMgmt;
import com.nty.coursemgmt.data.User;
import com.nty.coursemgmt.data.Student;
import com.nty.coursemgmt.data.UserMgmt;
import com.nty.coursemgmt.*;
import com.nty.coursemgmt.common.GeneralGrid;

import com.nty.coursemgmt.common.UIUtility;
import java.util.ArrayList;
import static com.nty.coursemgmt.common.UIUtility.inputItem;
public 
        class StudentMaintainUI {
	public void showUI(){
		int select=0;
		do{
			select=UIUtility.printMenu(new String[]{"1.学生信息查询","2.添加学生","3.删除学生","0.退出"});
			switch(select){
				case 1:
					studentQuery();
					break;
				case 2:
					addUser();
					break;
				case 3:
					deleteUser();
					break;
				default:
					break;
			}
				
		}while(select!=0);
	}
	
	private void studentQuery(){
		int select=0;
		do{
			select=UIUtility.printMenu(new String[]{"1.按学号查询","2.按姓名查询","3.按班级查询","0.退出"});
			switch(select){
				case 1:
					queryStudentById();
					break;
				case 2:
					queryStudentByName();
					break;
				case 3:
					queryStudentByClassName();
				default:
					break;
			}		
		}while(select!=0);
	}
	
	private void queryStudentById(){
		String userId=inputItem("请输入学号:");
		ArrayList<Student> sts=new ArrayList<Student>();
		User user=UserMgmt.getInstance(false).findUserById(userId);
		if(user==null){
			System.out.println("无法查到该学生!!");
			return;
		}
		if(user!=null){
			if(user instanceof Student){
				Student stu=(Student)user;
				sts.add(stu);
				StudentPrintMenu(sts);
				return;
			}
		}
		System.out.println("无法查到该学生!!");
	}
	
	private void queryStudentByName(){
		String name=inputItem("请输入姓名:");
		ArrayList<Student> sts=new ArrayList<Student>();
		Student c=UserMgmt.getInstance(false).findUserByName(name);
		if(c!=null){
			sts.add(c);
			StudentPrintMenu(sts);
			return;
		}
		if(c==null){
			System.out.println("无法查到该学生!!");
		}
	}
	
	private void queryStudentByClassName(){
		String className=inputItem("请输入班级");
		ArrayList<Student> sts=UserMgmt.getInstance(false).findUserByClassName(className);
		if(sts.isEmpty()){
			System.out.println("无该班级!!");
		
		}else{
			StudentPrintMenu(sts);
			return;
		}
		
	}

	private void StudentPrintMenu(ArrayList<Student> sts){
		GeneralGrid grid=new GeneralGrid();
		grid.setTableName("学生信息查询结果");
		grid.setHasIndexColumn(true);
		grid.setHeader(new String[]{"学号","姓名","班级名"});
		for(Student c:sts){
			grid.addRow(new String[]{c.getUserId(),c.getUserName(),c.getMyClassName()});
		}
		grid.ShowTable();
	}
	
	public void addUser(){
		String userId=inputItem("userId");
		String userName=inputItem("userName");
		String password=inputItem("possword");
		String className=inputItem("className");
		
		Student c=new Student();
		c.setStudentId(userId);
		c.setStudentName(userName);
		c.setMyClassName(className);
		c.setUserPossword(password);
//		c.setUserType("st");
		UserMgmt.getInstance(false).addUser(c);
		UserMgmt.getInstance(false).save();
		System.out.println("创建成功");	
	}
	
	private void deleteUser(){
		String id=inputItem("请输入要删除的学号");
		UserMgmt.getInstance(false).deleteUser(id);
		UserMgmt.getInstance(false).save();
		
		UserCourseRelationMgmt.getInstance(false).deleteRel(id);
		UserCourseRelationMgmt.getInstance(false).save();
		System.out.println("删除成功!!");
	}
}
