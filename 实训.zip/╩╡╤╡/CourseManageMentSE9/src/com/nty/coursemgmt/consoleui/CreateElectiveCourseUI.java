package com.nty.coursemgmt.consoleui;
import com.nty.coursemgmt.data.CourseType;
import com.nty.coursemgmt.data.Course;
import com.nty.coursemgmt.data.Teacher;
import com.nty.coursemgmt.data.CourseMgmt;
import com.nty.coursemgmt.*;
import java.util.Scanner;
import static com.nty.coursemgmt.common.UIUtility.inputItem;
public class CreateElectiveCourseUI {
	public void showUI(Teacher th){
		String courseName=inputItem("课程名");
		String textBook=inputItem("教材");
		String credit=inputItem("学分");
		String time=inputItem("时间");
		String classroom=inputItem("教室");
	/*	String courseType=inputItem("类型");
		CourseType tmp=null; 
		if(courseType.equals("E")){
			tmp=CourseType.ELECTIVE;
		}else if(courseType.equals("M")){
			tmp=CourseType.MUST;
		}*/
		Course c=new Course();
		c.setCourse(courseName);
		c.setTextbook(textBook);
		c.setCredit(credit);
		c.setTeacherId(th.getTeacherId());
		c.setTime(time);
		c.setClassroom(classroom);
		c.setMyClassName("na");
		c.setCourseType(CourseType.ELECTIVE);
		CourseMgmt.getInstance(false).addCourse(c);
		CourseMgmt.getInstance(false).save();
		System.out.println("创建成功");
	}

}
