package com.nty.coursemgmt.data;
import com.nty.coursemgmt.consoleui.CourseQueryUI;
import com.nty.coursemgmt.consoleui.CreateElectiveCourseUI;
import com.nty.coursemgmt.consoleui.StudentMaintainUI;
import com.nty.coursemgmt.consoleui.ElectCourseUI;
import com.nty.coursemgmt.consoleui.TeacherCourseQueryUI;
import com.nty.coursemgmt.common.UserLogon;
import com.nty.coursemgmt.common.UIUtility;
import java.util.Scanner;

public class mainUI {
	public static void printStr(String str){
		System.out.print(str+"\t");
	}
	public static void showUI(User user){
       		if(user instanceof Student){
       			mainUI.showStudentUI();
       		}
       		if(user instanceof Teacher){
       			mainUI.showTeacherUI();
       		}
       		if(user instanceof Admin){
       			mainUI.showAdminUI();
       		}
       		
       		
	}
	
	public static void showStudentUI(){
		int select=0;
		do{
			select=UIUtility.printMenu(new String[]{"1.查询课表","2.选课","0.退出"});
			switch(select){
				case 1:
					CourseQueryUI.showUI((Student)UserLogon.getCurrentUser());
					break;
				case 2:
					new ElectCourseUI().showUI((Student)UserLogon.getCurrentUser());	
				default:
					break;
			}
				
		}while(select!=0);
	}
	
	public static void showTeacherUI(){
		int select=0;
		do{
			select=UIUtility.printMenu(new String[]{"1.查看课程列表","2.创建选课","0.退出"});	
			switch(select){
				case 1:
					new TeacherCourseQueryUI().showUI((Teacher)UserLogon.getCurrentUser());
					break;
				case 2:
					new CreateElectiveCourseUI().showUI((Teacher)UserLogon.getCurrentUser());
					break;
				default:
					break;
					
			}
		}while(select!=0);
	}
	
	public static void showAdminUI(){
		int select=0;
		do{
			select=UIUtility.printMenu(new String[]{"1.学生信息维护","2.教师信息维护","3.课程信息维护","0.退出"});	
			switch(select){
				case 1:
					new StudentMaintainUI().showUI();
					break;
				case 2:
					break;
				case 3:
					break;
				default:
					break;
			}
		}while(select!=0);
	}
	
}
