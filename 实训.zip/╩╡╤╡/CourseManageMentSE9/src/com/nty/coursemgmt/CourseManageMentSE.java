/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.nty.coursemgmt;

import com.nty.coursemgmt.gui.LogonWindow;

/**
 *
 * @author Administrator
 */
 class CourseManageMentSE {

    public static void main(String[] args){
        System.out.println("SE main");
        new LogonWindow().setVisible(true);
    }
}
